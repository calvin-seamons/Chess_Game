package Handlers;

import Models.ClearApplicationResult;

public class ClearApplicationHandler {
    public ClearApplicationHandler(){}

    /**
     * Creates a clearApplication HTTP string
     * @return a clearApplication HTTP string
     */
    public String clearApplicationRequestToHTTP() {
        return null;
    }

    /**
     * Converts a clearApplication HTTP string into a ClearApplicationResult object
     * @param responseBody the clearApplication HTTP string to convert
     * @return a ClearApplicationResult object
     */
    public ClearApplicationResult HTTPToClearApplicationResult(String responseBody) {
        return null;
    }
}
