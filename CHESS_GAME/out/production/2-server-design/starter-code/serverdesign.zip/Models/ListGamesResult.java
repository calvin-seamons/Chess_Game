package Models;

public class ListGamesResult {
    private Game[] games;

    public ListGamesResult() {}

    public Game[] getGames() {
        return games;
    }

    public void setGames(Game[] games) {
        this.games = games;
    }

}
