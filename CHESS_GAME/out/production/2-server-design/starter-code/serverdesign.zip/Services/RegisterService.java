package Services;

import Models.RegisterRequest;
import Models.RegisterResult;

public class RegisterService {
    /**
     * Allows a user to register a new account
     * @param request the RegisterRequest object to convert
     * @return a RegisterResult object
     */
    public RegisterResult register(RegisterRequest request) {
        return null;
    }
}
