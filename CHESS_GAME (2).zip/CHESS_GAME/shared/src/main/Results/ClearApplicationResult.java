package Results;

/**
 * ClearApplicationResult contains the message that the clear application service returns
 */
public class ClearApplicationResult {
    private String message;

    public ClearApplicationResult() {}

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
